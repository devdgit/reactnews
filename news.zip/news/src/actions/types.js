export const SET_NEWS_SOURCE = "SET_NEWS_SOURCE";
export const GET_NEWS = "GET_NEWS";
export const GET_NEWS_SOURCES = "GET_NEWS_SOURCES";
