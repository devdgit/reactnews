
const
    gulp = require('gulp'),
    concat = require ('gulp-concat'),
    sass=require('gulp-sass');

gulp.task('footercss',async function(){
    gulp.src('components/footer/*.css')
    .pipe(concat('style.css'))
    .pipe(gulp.dest('build/styles/'));
});

gulp.task('newsscss',async function(){
    gulp.src('components/news/*.scss')
    .pipe(sass().on('error', sass.logError))
    .pipe(gulp.dest('build/styles/'));
});

gulp.task('navbarjs',async function(){
    gulp.src('components/navbar/*.js')
    .pipe(concat('navcon.js'))
    .pipe(gulp.dest('build/js/'));
});

gulp.task('watch',async function(){
    gulp.watch('components/footer/*.css',gulp.series('footercss'));
    gulp.watch('components/news/*.scss',gulp.series('newsscss'));
    gulp.watch('components/navbar/*.js',gulp.series('navbarjs'));
});

gulp.task('default',gulp.series('footercss','newsscss','navbarjs','watch'));